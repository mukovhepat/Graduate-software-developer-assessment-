package com.enviro.assessment.grad001.MukovhePat.WasteSorting;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WasteSortingApplicationTests {

	@Test
	void contextLoads() {
	}

}
