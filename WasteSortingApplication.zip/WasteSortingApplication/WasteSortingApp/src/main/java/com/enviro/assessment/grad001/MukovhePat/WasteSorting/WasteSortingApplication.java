package com.enviro.assessment.grad001.MukovhePat.WasteSorting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WasteSortingApplication {

	public static void main(String[] args) {
		SpringApplication.run(WasteSortingApplication.class, args);
	}

}
