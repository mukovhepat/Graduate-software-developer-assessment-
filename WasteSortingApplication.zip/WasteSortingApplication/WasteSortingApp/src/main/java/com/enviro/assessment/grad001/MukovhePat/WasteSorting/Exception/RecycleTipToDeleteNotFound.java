package com.enviro.assessment.grad001.MukovhePat.WasteSorting.Exception;

public class RecycleTipToDeleteNotFound extends RuntimeException{

    public RecycleTipToDeleteNotFound(String message) {
        super(message);
    }
}
