package com.enviro.assessment.grad001.MukovhePat.WasteSorting.Exception;

public class CategoryToDeleteNotFound extends RuntimeException{
    public CategoryToDeleteNotFound(String message) {
        super(message);
    }
}
