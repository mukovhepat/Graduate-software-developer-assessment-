package com.enviro.assessment.grad001.MukovhePat.WasteSorting.Repository;

import com.enviro.assessment.grad001.MukovhePat.WasteSorting.Entity.RecyclingTip;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecycleTipsRepo extends JpaRepository<RecyclingTip,Long> {
}
