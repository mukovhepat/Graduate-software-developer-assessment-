package com.enviro.assessment.grad001.MukovhePat.WasteSorting.Exception;

public class GuidelineToDeleteException extends RuntimeException{
    public GuidelineToDeleteException(String message) {
        super(message);
    }
}
