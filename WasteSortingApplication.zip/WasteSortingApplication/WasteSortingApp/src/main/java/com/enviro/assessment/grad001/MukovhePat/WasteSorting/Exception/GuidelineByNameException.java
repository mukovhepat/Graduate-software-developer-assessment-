package com.enviro.assessment.grad001.MukovhePat.WasteSorting.Exception;

public class GuidelineByNameException extends RuntimeException{
    public GuidelineByNameException(String message) {
        super(message);
    }
}
