package com.enviro.assessment.grad001.MukovhePat.WasteSorting.Exception;

public class GuidelineNotFoundException extends RuntimeException{

    public GuidelineNotFoundException(String message) {
        super(message);
    }
}
