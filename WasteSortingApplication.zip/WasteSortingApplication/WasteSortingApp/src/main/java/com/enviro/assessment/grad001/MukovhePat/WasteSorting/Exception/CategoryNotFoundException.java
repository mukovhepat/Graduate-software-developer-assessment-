package com.enviro.assessment.grad001.MukovhePat.WasteSorting.Exception;

public class CategoryNotFoundException extends RuntimeException{
    public CategoryNotFoundException(String message) {
        super(message);
    }
}
