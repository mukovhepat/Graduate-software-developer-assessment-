package com.enviro.assessment.grad001.MukovhePat.WasteSorting.Exception;

public class CreateGuidelineException extends RuntimeException{

    public CreateGuidelineException(String message) {
        super(message);
    }
}
