package com.enviro.assessment.grad001.MukovhePat.WasteSorting.Exception;

public class RecycleTipNotFoundException extends RuntimeException{

    public RecycleTipNotFoundException(String message) {
        super(message);
    }
}
