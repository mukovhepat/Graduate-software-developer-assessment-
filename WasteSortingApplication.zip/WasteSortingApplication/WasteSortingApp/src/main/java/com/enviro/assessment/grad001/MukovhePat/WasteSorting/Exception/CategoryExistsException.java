package com.enviro.assessment.grad001.MukovhePat.WasteSorting.Exception;

public class CategoryExistsException extends RuntimeException{
    public CategoryExistsException(String message) {
        super(message);
    }
}
