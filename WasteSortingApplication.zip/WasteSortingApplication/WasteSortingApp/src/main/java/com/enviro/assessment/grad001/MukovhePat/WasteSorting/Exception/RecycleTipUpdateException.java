package com.enviro.assessment.grad001.MukovhePat.WasteSorting.Exception;

public class RecycleTipUpdateException extends RuntimeException{

    public RecycleTipUpdateException(String message) {
        super(message);
    }
}
